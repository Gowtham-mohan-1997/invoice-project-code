package Testcase_ITBGD;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import common_function.common_function;
import page_function.iniatiator_pages;
import page_function.login_page;
import page_function.lookup_fucntion;
import page_function.utility;

public class T5_create_ForeignpaymentClosingbalance_request_complete_with_chiefaccountant extends common_function{
	public String requestid ;

	public void iniatiator() throws InterruptedException {
		PageFactory.initElements(driver, login_page.class);
		login_page.username.sendKeys(properties.getProperty("iniatiator"));
		Thread.sleep(1000);
		login_page.password.sendKeys(properties.getProperty("password"));
		Thread.sleep(1000);
		login_page.login.click();
		Thread.sleep(1000);
	}

	public void manager() throws InterruptedException {
		PageFactory.initElements(driver, login_page.class);
		login_page.username.sendKeys(properties.getProperty("manager"));
		Thread.sleep(1000);
		login_page.password.sendKeys(properties.getProperty("password"));
		Thread.sleep(1000);
		login_page.login.click();
		Thread.sleep(1000);
	}
	public void accountant() throws InterruptedException {
		PageFactory.initElements(driver, login_page.class);
		login_page.username.sendKeys(properties.getProperty("accountant"));
		Thread.sleep(1000);
		login_page.password.sendKeys(properties.getProperty("password"));
		Thread.sleep(1000);
		login_page.login.click();
		Thread.sleep(1000);
	}
	public void chiefaccountant() throws InterruptedException {
		PageFactory.initElements(driver, login_page.class);
		login_page.username.sendKeys(properties.getProperty("chiefaccountant"));
		Thread.sleep(1000);
		login_page.password.sendKeys(properties.getProperty("password"));
		Thread.sleep(1000);
		login_page.login.click();
		Thread.sleep(1000);
	}
	
	@Test(priority = 1)
	public void S1_create_newrequest() throws InterruptedException {
		
		iniatiator();
		PageFactory.initElements(driver, iniatiator_pages.class);
		PageFactory.initElements(driver, utility.class);
		PageFactory.initElements(driver, lookup_fucntion.class);

		utility.clickWithWait(iniatiator_pages.transactionlist);
		Thread.sleep(1000);
		utility.clickWithWait(iniatiator_pages.ITBGD);
		Thread.sleep(1000);
		utility.clickWithWait(iniatiator_pages.create);
		Thread.sleep(1000);
		utility.clickWithWait(lookup_fucntion.subrequest);
		Thread.sleep(1000);
		lookup_fucntion.selectlookupvalue("Foreign payment - Closing balance");
		Thread.sleep(1000);
		
	
		iniatiator_pages.invoicenumber.sendKeys("123");
		Thread.sleep(1000);
		
		iniatiator_pages.beneficiarybankname.sendKeys("name");
		Thread.sleep(1000);
		iniatiator_pages.beneficiaryregistrationname.sendKeys("name1");
		Thread.sleep(1000);
		iniatiator_pages.beneficiaryaccountnumber.sendKeys("456");
		Thread.sleep(1000);
		utility.clickWithWait(iniatiator_pages.invoiceduedate);
		Thread.sleep(1000);
		utility.clickWithWait(iniatiator_pages.calenderdate);
		Thread.sleep(1000);
		iniatiator_pages.memo.sendKeys("/home/gautham/Downloads/mongolianlanguage.png");
		Thread.sleep(1000);
		iniatiator_pages.invoice.sendKeys("/home/gautham/Downloads/mongolianlanguage.png");
		Thread.sleep(1000);
		iniatiator_pages.contractoriginal1.sendKeys("/home/gautham/Downloads/mongolianlanguage.png");
		Thread.sleep(1000);
		iniatiator_pages.DT01.sendKeys("/home/gautham/Downloads/mongolianlanguage.png");
		Thread.sleep(1000);
		iniatiator_pages.taxcertificate.sendKeys("/home/gautham/Downloads/mongolianlanguage.png");
		Thread.sleep(1000);
		iniatiator_pages.approvalforITSM.sendKeys("/home/gautham/Downloads/mongolianlanguage.png");
		Thread.sleep(1000);
		iniatiator_pages.others.sendKeys("/home/gautham/Downloads/mongolianlanguage.png");
		Thread.sleep(1000);
		
		iniatiator_pages.amount.sendKeys("100");
		Thread.sleep(1000);
	
		utility.clickWithWait(lookup_fucntion.currency);
		Thread.sleep(1000);
		lookup_fucntion.selectlookupvalue("AUD");
		Thread.sleep(1000);
		utility.clickWithWait(lookup_fucntion.budgetcode);
		Thread.sleep(1000);
		lookup_fucntion.selectlookupvalue("HO-2-3");
		Thread.sleep(1000);
		
		iniatiator_pages.newassetname.sendKeys("123");
		Thread.sleep(1000);
		iniatiator_pages.newassetlifetimeduration.sendKeys("123");
		Thread.sleep(1000);
		iniatiator_pages.responsibleofficer.sendKeys("123");
		Thread.sleep(1000);
		iniatiator_pages.description.sendKeys("123");
		Thread.sleep(1000);
		iniatiator_pages.actofprogramandservicescompletion.sendKeys("/home/gautham/Downloads/mongolianlanguage.png");
		Thread.sleep(1000);
		
		
		JavascriptExecutor jb = (JavascriptExecutor) driver;
		jb.executeScript("window.scrollBy(0,-1000)");
		Thread.sleep(1000);
		utility.clickWithWait(iniatiator_pages.create);
		Thread.sleep(1000);
		String actualelement = iniatiator_pages.actualelement.getText();
		System.out.println("iniatiator request status-->" + actualelement);
		utility.clickWithWait(iniatiator_pages.listlatestrequest);
		Thread.sleep(1000);
		 requestid = iniatiator_pages.requestid.getText();
		System.out.println("iniatiator request id-->" + requestid);
		Thread.sleep(1000);
		System.out.println("iniatiator request completed successfully");
		
		utility.clickWithWait(iniatiator_pages.logout1);
		Thread.sleep(1000);
		utility.clickWithWait(iniatiator_pages.logout2);
		Thread.sleep(1000);
		
		



	}

	@Test(priority = 2)
	public void S2_complete_managertask_withapprove() throws InterruptedException {

		manager();

		PageFactory.initElements(driver, iniatiator_pages.class);
		PageFactory.initElements(driver, utility.class);
		PageFactory.initElements(driver, lookup_fucntion.class);

		utility.clickWithWait(iniatiator_pages.ITBGDworkflow);
		Thread.sleep(1000);
		utility.clickWithWait(iniatiator_pages.ITBGDworkflowlatestrequest);
		Thread.sleep(1000);

		Boolean s = true;
		while (s.equals(true))

		{

			String requestnumber = iniatiator_pages.requestnumber.getText();

			System.out.println("manager request number : ->" + requestnumber);

			if (requestnumber.contains(requestid)) {

				System.out.println("Yeah... expect request number matched");

				s = false;

				Thread.sleep(1000);

				JavascriptExecutor jb = (JavascriptExecutor) driver;
				jb.executeScript("window.scrollBy(0,1000)");
				Thread.sleep(1000);

				utility.clickWithWait(lookup_fucntion.departmentmanagerdecision);

				Thread.sleep(1000);
				lookup_fucntion.selectlookupvalue("Approve");
				Thread.sleep(1000);
			iniatiator_pages.departmentmanagerremarks.sendKeys("approve");;

				Thread.sleep(1000);
				jb.executeScript("window.scrollBy(0,-1000)");

				utility.clickWithWait(iniatiator_pages.completetask);
				String actualelement = iniatiator_pages.actualelement.getText();
				System.out.println("manager request status-->" + actualelement);
				Thread.sleep(3000);
				System.out.println("manager request completed successfully");
				utility.clickWithWait(iniatiator_pages.inbox);
				Thread.sleep(1000);
				for (int i = 0; i < 60; i++) {
					try {
						iniatiator_pages.logout1.click();
						Thread.sleep(2000);
						iniatiator_pages.logout2.click();
						break;
					} catch (Exception f) {
						Thread.sleep(1000);
					}

				}

			} else {
				for (int i = 0; i < 20; i++) {

					Thread.sleep(3000);

					try {
						utility.clickWithWait(iniatiator_pages.inbox);
						Thread.sleep(1000);
						utility.clickWithWait(iniatiator_pages.ITBGDworkflow);
						Thread.sleep(1000);
						utility.clickWithWait(iniatiator_pages.ITBGDworkflowlatestrequest);
						Thread.sleep(1000);


						break;
					} catch (Exception e) {
						Thread.sleep(1000);
					}
				}
			}
		}

	}
	@Test(priority = 3)
	public void S3_complete_accountanttask_withapprove() throws InterruptedException {

		accountant();

		PageFactory.initElements(driver, iniatiator_pages.class);
		PageFactory.initElements(driver, utility.class);
		PageFactory.initElements(driver, lookup_fucntion.class);

		utility.clickWithWait(iniatiator_pages.ITBGDworkflow);
		Thread.sleep(1000);
		utility.clickWithWait(iniatiator_pages.ITBGDworkflowlatestrequest);
		Thread.sleep(1000);


		Boolean s = true;
		while (s.equals(true))

		{

			String requestnumber = iniatiator_pages.requestnumber.getText();

			System.out.println("manager request number : ->" + requestnumber);

			if (requestnumber.contains(requestid)) {

				System.out.println("Yeah... expect request number matched");

				s = false;

				Thread.sleep(1000);

				JavascriptExecutor jb = (JavascriptExecutor) driver;
				jb.executeScript("window.scrollBy(0,1000)");
				Thread.sleep(1000);

				utility.clickWithWait(lookup_fucntion.accountantdecision);

				Thread.sleep(1000);
				lookup_fucntion.selectlookupvalue("Approve");
				Thread.sleep(1000);
			iniatiator_pages.accountantremarks.sendKeys("approve");;

				Thread.sleep(1000);
				utility.clickWithWait(lookup_fucntion.nextapproverselection);

				Thread.sleep(1000);
				lookup_fucntion.selectlookupvalue("Chief Accountant");
				jb.executeScript("window.scrollBy(0,-1000)");

				utility.clickWithWait(iniatiator_pages.completetask);
				String actualelement = iniatiator_pages.actualelement.getText();
				System.out.println("manager request status-->" + actualelement);
				Thread.sleep(3000);
				System.out.println("accountant request completed successfully");
				utility.clickWithWait(iniatiator_pages.inbox);
				Thread.sleep(1000);
				for (int i = 0; i < 60; i++) {
					try {
						iniatiator_pages.logout1.click();
						Thread.sleep(2000);
						iniatiator_pages.logout2.click();
						break;
					} catch (Exception f) {
						Thread.sleep(1000);
					}

				}

			} else {
				for (int i = 0; i < 20; i++) {

					Thread.sleep(3000);

					try {
						utility.clickWithWait(iniatiator_pages.inbox);
						Thread.sleep(1000);
						utility.clickWithWait(iniatiator_pages.ITBGDworkflow);
						Thread.sleep(1000);
						utility.clickWithWait(iniatiator_pages.ITBGDworkflowlatestrequest);
						Thread.sleep(1000);


						break;
					} catch (Exception e) {
						Thread.sleep(1000);
					}
				}
			}
		}

	}
	@Test(priority = 4)
	public void S4_complete_chiefaccountanttask_withapprove() throws InterruptedException {

		chiefaccountant();

		PageFactory.initElements(driver, iniatiator_pages.class);
		PageFactory.initElements(driver, utility.class);
		PageFactory.initElements(driver, lookup_fucntion.class);

		utility.clickWithWait(iniatiator_pages.ITBGDworkflow);
		Thread.sleep(1000);
		utility.clickWithWait(iniatiator_pages.ITBGDworkflowlatestrequest);
		Thread.sleep(1000);


		Boolean s = true;
		while (s.equals(true))

		{

			String requestnumber = iniatiator_pages.requestnumber.getText();

			System.out.println("manager request number : ->" + requestnumber);

			if (requestnumber.contains(requestid)) {

				System.out.println("Yeah... expect request number matched");

				s = false;

				Thread.sleep(1000);

				JavascriptExecutor jb = (JavascriptExecutor) driver;
				jb.executeScript("window.scrollBy(0,1000)");
				Thread.sleep(1000);

				utility.clickWithWait(lookup_fucntion.chiefaccountantdecision);

				Thread.sleep(1000);
				lookup_fucntion.selectlookupvalue("Approve");
				Thread.sleep(1000);
			iniatiator_pages.chiefaccountantremark.sendKeys("approve");;

				Thread.sleep(1000);
				
				jb.executeScript("window.scrollBy(0,-1000)");

				utility.clickWithWait(iniatiator_pages.completetask);
				String actualelement = iniatiator_pages.actualelement.getText();
				System.out.println("chiefaccountant request status-->" + actualelement);
				Thread.sleep(3000);
				System.out.println("chiefaccountant request completed successfully");
				utility.clickWithWait(iniatiator_pages.inbox);
				Thread.sleep(1000);
				for (int i = 0; i < 60; i++) {
					try {
						iniatiator_pages.logout1.click();
						Thread.sleep(2000);
						iniatiator_pages.logout2.click();
						break;
					} catch (Exception f) {
						Thread.sleep(1000);
					}

				}

			} else {
				for (int i = 0; i < 20; i++) {

					Thread.sleep(3000);

					try {
						utility.clickWithWait(iniatiator_pages.inbox);
						Thread.sleep(1000);
						utility.clickWithWait(iniatiator_pages.ITBGDworkflow);
						Thread.sleep(1000);
						utility.clickWithWait(iniatiator_pages.ITBGDworkflowlatestrequest);
						Thread.sleep(1000);


						break;
					} catch (Exception e) {
						Thread.sleep(1000);
					}
				}
			}
		}

	}
	@Test(priority = 5)
	public void S5_complete_maketransactiontask() throws InterruptedException {

		accountant();

		PageFactory.initElements(driver, iniatiator_pages.class);
		PageFactory.initElements(driver, utility.class);
		PageFactory.initElements(driver, lookup_fucntion.class);

		utility.clickWithWait(iniatiator_pages.ITBGDworkflow);
		Thread.sleep(1000);
		utility.clickWithWait(iniatiator_pages.ITBGDworkflowlatestrequest);
		Thread.sleep(1000);


		Boolean s = true;
		while (s.equals(true))

		{

			String requestnumber = iniatiator_pages.requestnumber.getText();

			System.out.println("manager request number : ->" + requestnumber);

			if (requestnumber.contains(requestid)) {

				System.out.println("Yeah... expect request number matched");

				s = false;

				Thread.sleep(1000);

				JavascriptExecutor jb = (JavascriptExecutor) driver;
				jb.executeScript("window.scrollBy(0,1000)");
				Thread.sleep(1000);

				iniatiator_pages.supportingdocument.sendKeys("/home/gautham/Downloads/Report Other than Computer (1).xlsx");
				Thread.sleep(1000);
			iniatiator_pages.PRDmaketransactionremarks.sendKeys("approve");;

				Thread.sleep(1000);
				
				jb.executeScript("window.scrollBy(0,-1000)");

				utility.clickWithWait(iniatiator_pages.completetask);
				String actualelement = iniatiator_pages.actualelement.getText();
				System.out.println("make transaction request status-->" + actualelement);
				Thread.sleep(3000);
				System.out.println("make transaction request completed successfully");
				utility.clickWithWait(iniatiator_pages.inbox);
				Thread.sleep(1000);
				for (int i = 0; i < 60; i++) {
					try {
						iniatiator_pages.logout1.click();
						Thread.sleep(2000);
						iniatiator_pages.logout2.click();
						break;
					} catch (Exception f) {
						Thread.sleep(1000);
					}

				}

			} else {
				for (int i = 0; i < 20; i++) {

					Thread.sleep(3000);

					try {
						utility.clickWithWait(iniatiator_pages.inbox);
						Thread.sleep(1000);
						utility.clickWithWait(iniatiator_pages.ITBGDworkflow);
						Thread.sleep(1000);
						utility.clickWithWait(iniatiator_pages.ITBGDworkflowlatestrequest);
						Thread.sleep(1000);


						break;
					} catch (Exception e) {
						Thread.sleep(1000);
					}
				}
			}
		}

	}
}
