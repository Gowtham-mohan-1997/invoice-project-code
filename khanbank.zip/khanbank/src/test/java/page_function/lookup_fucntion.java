package page_function;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class lookup_fucntion {
	@FindBy(css = "kendo-multiselect#var18b947fa13b input")
	public static WebElement subrequest;
	
	@FindBy(css = "kendo-multiselect#var18b93b6e787 input")
	public static WebElement currency;
	
	@FindBy(css = "kendo-multiselect#var18b93b73b5d input")
	public static WebElement budgetcode;
	
	@FindBy(css = "kendo-combobox#var18ba85bbf8e button")
	public static WebElement departmentmanagerdecision;
	
	@FindBy(css = "kendo-combobox#var18ba85da04e button")
	public static WebElement accountantdecision;
	
	@FindBy(css = "kendo-combobox#var18ba85e7872 button")
	public static WebElement nextapproverselection;
	
	@FindBy(css = "kendo-combobox#var18ba8610226 button")
	public static WebElement chiefaccountantdecision;
	
	@FindBy(css = "kendo-combobox#var18ba862f797 button")
	public static WebElement FMDmanager;
	
	@FindBy(css = "kendo-combobox#var18ba864538c button")
	public static WebElement vicepresident;
	
	@FindBy(css = "kendo-combobox#var18ba865af4c button")
	public static WebElement CEO;
	

	@FindBy(css = "kendo-combobox#var18b93b26929 button")
	public static WebElement reason;
	
	@FindBy(css = "kendo-combobox#var18b04658dbf button")
	public static WebElement legalADdecision;
	
	
	@FindBy(css=".k-animation-container li")
	public static List<WebElement> type1;
	
	public static void selectlookupvalue(String... values)
	{
		
		
		for (String value : values) {
				for (WebElement e : type1) {
				if (e.getText().trim().contains(value))

				{
					e.click();
					break;
				}
			}
		}
		}

}
