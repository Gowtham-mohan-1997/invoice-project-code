package page_function;

public class sleeputils {
	
	
	 public static void sleepmilliseconds(long milliseconds) {
	        try {
	            Thread.sleep(milliseconds);
	        } catch (InterruptedException e) {
	            Thread.currentThread().interrupt();
	            System.err.println("Sleep interrupted: " + e.getMessage());
	        }
	    }
}
