package page_function;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class iniatiator_pages {

	@FindBy(xpath = "//span[text()=\" Transaction List \"]")
	public static WebElement transactionlist;
	
	@FindBy(css = "span[title=\"VMD\"]")
	public static WebElement VMD;
	
	@FindBy(xpath = "//span[text()=\" PRD \"]")
	public static WebElement PRD;
	
	@FindBy(xpath = "//span[text()=\" ITBGD \"]")
	public static WebElement ITBGD;
	
	
	@FindBy(css = "button span[title=\"Create\"]")
	public static WebElement create;
	
	@FindBy(css = "kendo-textbox#var18b93a97211 input")
	public static WebElement invoicenumber;
	
	@FindBy(css = "kendo-textbox#var18b93aa31fe input")
	public static WebElement beneficiarybankname;
	
	@FindBy(css = "kendo-textbox#var18b93aacbd4 input")
	public static WebElement beneficiaryregistrationname;
	
	@FindBy(css = "kendo-textbox#var18b93aa7eac input")
	public static WebElement beneficiaryaccountnumber;
	
	@FindBy(css = "kendo-datepicker#var18b93a9eea4 button")
	public static WebElement invoiceduedate;
	
	@FindBy(css = "kendo-numerictextbox#var18b93b6c558 input")
	public static WebElement amount;
	
	@FindBy(css = "kendo-textbox#var18b93b70a7e input")
	public static WebElement description;
	
	@FindBy(css = "div#var18b93b64226 kendo-upload div input")
	public static WebElement invoice;
	
	@FindBy(css = "div#var18b93b66e5a kendo-upload div input")
	public static WebElement VATreceipt;
	
	@FindBy(css = "div#var18b93dac64c kendo-upload div input")
	public static WebElement memo;
	
	@FindBy(css = "div#var18b93b77a0c kendo-upload div input")
	public static WebElement consentform;
	
	@FindBy(css = "div#var18b93ab2b58 kendo-upload div input")
	public static WebElement receiptofexpenditure;
	
	@FindBy(css = "div#var18b93abce5e kendo-upload div input")
	public static WebElement actofassetreceipt;
	
	@FindBy(css = "div#var18b93b6942a kendo-upload div input")
	public static WebElement others;
	
	@FindBy(css = "div#var18b93c7d6aa kendo-upload div input")
	public static WebElement ContractConclusionAct;
	@FindBy(css = "div#var18b93ac6a4d kendo-upload div input")
	public static WebElement ContractConclusionActvmd;
	
	@FindBy(css = "div#var18b93af321d kendo-upload div input")
	public static WebElement PropertyAcceptanceAct;
	
	@FindBy(css = "div#var18b93c88c36 kendo-upload div input")
	public static WebElement DetailsOfContractPerformance;
	
	@FindBy(css = "div#var18b93add03a kendo-upload div input")
	public static WebElement DetailsOfContractPerformancevmd;
	
	@FindBy(css = "div#var18b93afa98a kendo-upload div input")
	public static WebElement Ifthecontracthasbeenamendedpleaseattachtheoriginalcontract;
	
	
	
	@FindBy(css = "div#var18b93ac2aef kendo-upload div input")
	public static WebElement originalcontract;
	
	@FindBy(css = "div#var18b93c7977b kendo-upload div input")
	public static WebElement contractoriginal;
	
	@FindBy(css = "div#var18b93c932c9 kendo-upload div input")
	public static WebElement RelatedPicturesOtherDocs;
	
	@FindBy(css = "div#var18b93c8d121 kendo-upload div input")
	public static WebElement ActofRepairReceived;
	
	@FindBy(css = ".k-calendar-nav-today")
	public static WebElement calenderdate;
	
	@FindBy(css = "kendo-grid-list div table tbody[role=\"presentation\"] tr[data-kendo-grid-item-index=\"0\"]")
	public static WebElement listlatestrequest;
	
	@FindBy(xpath = "/html/body/app-root/app-app-container/div[1]/div[2]/div[3]/app-app-common-detail/div[2]/div/div/div[1]/div")
	public static WebElement requestid;
	
	@FindBy(css = "button[fillmode=\"flat\"] span h3")
	public static WebElement logout1;
	
	@FindBy(css = "button[title=\"Logout\"]")
	public static WebElement logout2;
	
	@FindBy(xpath = "//td[text()=\" VMD Workflow \"]")
	public static WebElement VMDworkflow;
	
	@FindBy(css = "kendo-grid-list div table tbody[role=\"presentation\"] tr[data-kendo-grid-item-index=\"0\"]")
	public static WebElement VMDworkflowlatestrequest;
	
	@FindBy(xpath = "//td[text()=\" PRD Workflow \"]")
	public static WebElement PRDworkflow;
	
	@FindBy(xpath = "//td[text()=\" ITBGD Workflow \"]")
	public static WebElement ITBGDworkflow;
	
	@FindBy(css = "kendo-grid-list div table tbody[role=\"presentation\"] tr[data-kendo-grid-item-index=\"0\"]")
	public static WebElement ITBGDworkflowlatestrequest;
	
	@FindBy(css = "kendo-grid-list div table tbody[role=\"presentation\"] tr[data-kendo-grid-item-index=\"0\"]")
	public static WebElement PRDworkflowlatestrequest;
	
	
	@FindBy(xpath = "/html/body/app-root/app-app-container/div[1]/div[2]/div[3]/app-task-details/div/div/div/div/div[1]/div/div/div[2]/div/div/div[3]/div[2]")
	public static WebElement requestnumber;
	
	@FindBy(xpath = "//span[text()=\"Complete Task\"]")
	public static WebElement completetask;
	
	@FindBy(className="k-notification-group")
	public static WebElement actualelement;
	
	@FindBy(xpath="//span[text()=\" Inbox \"]")
	public static WebElement inbox;

	
	@FindBy(css = "kendo-textarea#var18ba85c8322 textarea")
	public static WebElement departmentmanagerremarks;
	
	
	@FindBy(css = "kendo-textarea#var18ba85fdfc4 textarea")
	public static WebElement accountantremarks;
	
	@FindBy(css = "kendo-textarea#var18ba861ec24 textarea")
	public static WebElement chiefaccountantremark;	
	
	@FindBy(css = "div#var18bb2fd7190 kendo-upload div input")
	public static WebElement supportingdocument;	
	
	@FindBy(css = "kendo-textarea#var18c16317cd2 textarea")
	public static WebElement maketransactionremarks;
	
	@FindBy(css = "kendo-textarea#var18bb2fddc8c textarea")
	public static WebElement PRDmaketransactionremarks;

	@FindBy(css = "kendo-textarea#var18ba863ab87 textarea")
	public static WebElement FMDmanagerremarks;
	
	@FindBy(css = "kendo-textarea#var18ba864f1ed textarea ")
	public static WebElement vicepresidentremarks;
	
	@FindBy(css = "kendo-textarea#var18ba86683c8 textarea")
	public static WebElement CEOremarks;
	@FindBy(css = "kendo-textarea#var18c1015a84e textarea")
	public static WebElement CEOremarksprd;
	
	@FindBy(css = "kendo-textarea#var18c1015a84e textarea")
	public static WebElement CEOremarks1;
	
	@FindBy(css = "kendo-textbox#var18b93b28936 input")
	public static WebElement assetname;
	
	@FindBy(css = "kendo-textbox#var18b93b2b9b2 input")
	public static WebElement assetcode;
	
	@FindBy(css = "kendo-textbox#var18b93b53ea6 input")
	public static WebElement nameofemployeetransferringtheasset;
	
	@FindBy(css = "kendo-textbox#var18b93b2e3af input")
	public static WebElement nameofassetreceiver;
	
	@FindBy(css = "kendo-textbox#var18b93b58acd input")
	public static WebElement domainofemployeetransfferingtheasset;
	
	@FindBy(css = "kendo-textbox#var18b93b35c33 input")
	public static WebElement domainofassetreceiver;
	
	@FindBy(css = "kendo-textarea#var18b93b6146b textarea")
	public static WebElement comment;
	
	@FindBy(css = "div#var18b93b079c3 kendo-upload div input")
	public static WebElement propertyacceptanceform;
	
	@FindBy(css = "div#var18b93db7120 kendo-upload div input")
	public static WebElement taxcertificate;
	
	@FindBy(css = "div#var18b93db4f6a kendo-upload div input")
	public static WebElement DT01;
	
	@FindBy(css = "div#var18b93dbbab6 kendo-upload div input")
	public static WebElement approvalforITSM;
	
	@FindBy(css = "div#var18b93db1162 kendo-upload div input")
	public static WebElement contractoriginal1;
	
	@FindBy(css = "kendo-textbox#var18b93de712a input")
	public static WebElement newassetname;
	
	@FindBy(css = "kendo-textbox#var18b93dee42c input")
	public static WebElement newassetlifetimeduration;
	
	@FindBy(css = "kendo-textbox#var18b93df3675 input")
	public static WebElement responsibleofficer;
	
	@FindBy(css = "div#var18b93de04e4 kendo-upload div input")
	public static WebElement actofprogramandservicescompletion ;
	
	@FindBy(css = "kendo-textarea#var18c1015a84e textarea")
	public static WebElement CEOremarkitbgd ;
	
	
	
	
	
	
	
}
