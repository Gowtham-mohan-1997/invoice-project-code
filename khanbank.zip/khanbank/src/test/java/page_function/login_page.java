package page_function;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class login_page {
	@FindBy(css = "input[name=\"loginName\"]")
	public static WebElement username;
	
	@FindBy(css = "kendo-textbox[name=\"loginPassword\"] input")
	public static WebElement password;
	
	@FindBy(xpath = "//button[text()=\"Login\"]")
	public static WebElement login;
	
}
