package common_function;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

import io.github.bonigarcia.wdm.WebDriverManager;


public class common_function {
	public static WebDriver driver=null;
	public static Properties properties=null;
//	private static ExtentReports extent;
//    protected static ExtentTest test;

	

public static Properties loadpropertyfile() throws IOException {
	
	FileInputStream fileinputstream =new FileInputStream("configure.properties");
	properties =new Properties();
	properties.load(fileinputstream);
	return properties;
	
}

   


@BeforeClass
public void launchbrowser() throws IOException {
	
//	ExtentSparkReporter sparkReporter = new ExtentSparkReporter("ExtentReport.html");
//	sparkReporter.config().setTheme(Theme.STANDARD);
//       extent = new ExtentReports();
//       extent.attachReporter(sparkReporter);
//
//       // Initialize ExtentTest
//       test = extent.createTest("Your Test Name");

	loadpropertyfile();
	
	String browser =properties.getProperty("browser");
	
	String url =properties.getProperty("url");
	String location=properties.getProperty("driverlocation");
	
	
	
	
	
	
	WebDriverManager.chromedriver().setup();
	if(browser.equalsIgnoreCase("chrome")) {
		ChromeOptions ops=new ChromeOptions();
		ops.addArguments("--remote-allow-origins=*");
		System.setProperty("WebDriver.Chrome.Driver",location);
		driver=new 	ChromeDriver(ops);
	}else if(browser.equalsIgnoreCase("firefox")) {
		System.setProperty("WebDriver.Chrome.Driver",location);
		driver=new 	FirefoxDriver();
	}
	driver.manage().window().maximize();
	driver.get(url);
	driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	
}

@AfterClass
public void teardown() {
	//   extent.flush();
	driver.close();
	
	   
       // Closes the underlying stream and clears all resources
     
}




		
		
		
		
		
		
		
}
